## Usage

After installation, you will find an item "Export Multiple Images" in the plugin section of the title menu in the editor. Simply click on it. The usage is similar to the built-in image export feature of the software.

## Notes

The exported images contain the logos of "siyuan" and "ccds" (Chuancheng Design), which are located in the plugin source code at line 939. You can modify the plugin source code to remove them if desired.